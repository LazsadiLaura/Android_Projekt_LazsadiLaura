package com.example.covidtracker.api;

import android.telecom.Call;

import java.util.List;

import retrofit2.http.GET;
import retrofit2.Call;

public interface ApiInterface {

    static final String BASE_URL = "https://corona.lmao.ninja/v2/";

    @GET("countries")
    default Call<List<CountryData>> getCountryData()
}
